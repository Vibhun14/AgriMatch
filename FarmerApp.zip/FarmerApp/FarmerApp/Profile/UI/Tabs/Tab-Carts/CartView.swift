//
//  CartView.swift
//  Shopping
//
//  Created by Thanh Hoang on 17/3/25.
//

import SwiftUI

struct CartView: View {
    
    //MARK: - Properties
    
    //MARK: - Initializes
    
    //MARK: - Contents
    var body: some View {
        TitleView(title: "Cart")
    }
}

#Preview {
    CartView()
}
